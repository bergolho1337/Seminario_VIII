function Tiro (x,y) {
	this.x = x;
	this.y = y;
	this.vy = 80;
};
